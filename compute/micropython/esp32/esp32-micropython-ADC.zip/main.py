import time 
from machine import Pin,PWM,ADC


# 测试ADC是否可用
def adc_test ():

    adc =ADC(Pin(14))

    val = adc.read()#12位 0-4096
    val_u16=adc.read_u16()#真实 0-65536

    adc.atten(ADC.ATTN_11DB)

    while 1:
        print(f"adc:{adc.read()}")
        print(f"adc-u16:{adc.read_u16()}")
        time.sleep(0.2)

# ADC控制 获得ADC值 用于脉宽调制平均电压 控制LED亮度
def pwn_adc_led():  
    led =PWM(Pin(0) ,freq=1000)
    adc = ADC(Pin(14),atten=ADC.ATTN_11DB)

    while 1:
        # adc.read_u16()
        led.duty_u16(adc.read_u16())
        time.sleep(0.1)
        print(f"adc-u16:{adc.read_u16()}")

pwn_adc_led()