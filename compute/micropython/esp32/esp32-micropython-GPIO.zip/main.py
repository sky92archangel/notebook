import time 
from machine import Pin

#默认按钮接电源，一侧为高电平，所以给14端口一个低电平
pin_button = Pin(14,Pin.IN,Pin.PULL_DOWN)

pin_led=Pin(0,Pin.OUT)

#设置状态 避免长按重复判断
status = 0
while 1:
    if pin_button.value()==1:
        time.sleep_ms(80)
		#案件消抖检测
        if pin_button.value()==1 and status == 0:
            pin_led.value(not pin_led.value())
            status=1
        elif pin_button.value()==0:
            status=0
