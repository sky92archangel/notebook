import time 
from machine import Pin 
import network
import urequests

 

def connect_wifi(essid:str,password:str):
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.disconnect()

    print(f'scanning:{wlan.scan()}')
    print(f'connecting',end="")
    wlan.connect(essid,password)

    while not wlan.isconnected():
        print(".",end='')
        time.sleep(0.5)
    print('\n!!!connect success!!!\n')



connect_wifi('Wokwi-GUEST','')


def http_request_demo():

    request_params={"city":"上海","key":"a702b975fa48a063b1a57c938bafb47a"}
    url=f"http://apis.juhe.cn/simpleWeather/query?city={request_params.get('city')}&key={request_params.get('key')}"
    response = urequests.get(url)
    print(response.text)
    print(response.json())

    realtime = response.json()['result']['realtime']
    print(realtime)

http_request_demo()