import time 
from machine import Pin

button = Pin(12,Pin.IN,Pin.PULL_DOWN)
led=Pin(21,Pin.OUT)


def button_handler(button):
    # status=0
    time.sleep_ms(20)
    if button.value()==1  :
        led.value(not led.value()) 

  
# button.irq (handler,trigger) 
button.irq (button_handler,Pin.IRQ_RISING)

 