import time 
from machine import Pin,Timer
 


def timer_test():

    def timer_0_irq (timer_obj):
        print(0) 
    timer_0=Timer(0)
    timer_0.init( mode=Timer.PERIODIC,
                period=500,
                callback=timer_0_irq)
    
    def timer_1_irq (timer_obj):
        print(1) 
    timer_1=Timer(1)
    timer_1.init( mode=Timer.PERIODIC,
                period=100,
                callback=timer_1_irq)
     
    def timer_2_irq (timer_obj):
        print(2)
    timer_2=Timer(2)
    timer_2.init( mode=Timer.PERIODIC,
                period=1000,
                callback=timer_2_irq)
    
    def timer_3_irq (timer_obj):
        print(3)
    timer_3=Timer(3)
    timer_3.init( mode=Timer.PERIODIC,
                period=500,
                callback=timer_3_irq)



def timer_demo() :
    led_1=Pin(21,Pin.OUT)
    led_2=Pin(16,Pin.OUT)

    def timer_0_irq (timer_obj):
        led_1.value(not led_1.value())
    timer_0=Timer(0)
    timer_0.init( mode=Timer.PERIODIC,
                period=500,
                callback=timer_0_irq)
    while 1:
        time.sleep_ms(100)
        led_2.value(not led_2.value())

timer_demo()