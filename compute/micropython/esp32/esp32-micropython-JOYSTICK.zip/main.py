from machine import Pin,PWM,ADC
import time
 

def servo_test():

    #标准PWM信号周期固定为20ms
    # 0.5ms = 00 度= 0.5//20
    # 1.0ms = 45 度= 1.0//20
    # 1.5ms = 90 度= 1.5//20
    # 2.0ms = 135 度= 2.0//20
    # 2.5ms = 180 度= 2.5//20


    pwm_pin = Pin(13,Pin.OUT)

    servo_pwm =PWM(pwm_pin )
    servo_pwm.freq(50)

    servo_pwm.duty(int(1023*0.5/20))

    while 1:  
        servo_pwm.duty(int(1023*1.0/20))
        time.sleep(1)
        servo_pwm.duty(int(1023*2.0/20))
        time.sleep(1)
    
def joystick_test():
    ps2_x = ADC(Pin(15),atten=ADC.ATTN_11DB)
    ps2_y = ADC(Pin(2),atten=ADC.ATTN_11DB)
    ps2_button=Pin(4,Pin.IN)

    while 1:
        print(f"x:{ps2_x.read()},y:{ps2_y.read()},z:{ps2_button.value()}")
        time.sleep(0.2)




def control_demo():
    ps2_x = ADC(Pin(15),atten=ADC.ATTN_11DB)
    ps2_y = ADC(Pin(2),atten=ADC.ATTN_11DB)
 
    my_servo =PWM(Pin(13,Pin.OUT) ,freq=50)
  
    while 1 :
        x_val = ps2_x.read()

        servo_angle = x_val/4095*(2.4-0.5)/20*1024+0.5/20*1024
        my_servo.duty(round(servo_angle))
        time.sleep(0.2)
        
control_demo()