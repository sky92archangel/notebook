import time 
from machine import Pin 
import network


def create_ap(ap_name:str='esp32-ap'):
    ap = network.WLAN(network.AP_IF) 
    ap.active(True) 
    ap.config(essid=ap_name)

def connect_wifi(essid:str,password:str):
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    wlan.disconnect()

    print(f'scanning:{wlan.scan()}')
    print(f'connecting',end="")
    wlan.connect(essid,password)

    while not wlan.isconnected():
        print(".",end='')
        time.sleep(0.5)
    print('\n!!!connect success!!!\n')



connect_wifi('Wokwi-GUEST','')


 