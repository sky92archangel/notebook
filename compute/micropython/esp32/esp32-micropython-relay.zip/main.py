from machine import Pin,PWM,ADC
import time
 
relay_pin = Pin(15,Pin.OUT)

def relay_on():
    relay_pin.value(1)
 
def relay_off():
    relay_pin.value(0)

def blink():
    relay_on()
    time.sleep(0.5)
    relay_off()
    time.sleep(0.5)

while 1:
    blink()
