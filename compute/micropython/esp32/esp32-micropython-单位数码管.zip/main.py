import time 
from machine import Pin


'''
数码管公共类
共阳极（Common Anode）
共阴极（Common Cathode）
'''

class Seg :
    def __init__(self,
                    pin_idxs:list=[0,2,4,5,12,14,26,33],
                    is_anode=True):
        self.is_anode = is_anode
        self.led_lst=[ ]
        for pin_idx in pin_idxs :
            led = Pin(pin_idx,Pin.OUT)
            self.led_lst.append(led) 
        
        self.num_dict = {
            # [a,b,c,d,e,f,g,dp]
            0:[1,1,1,1,1,1,0,0],
            1:[0,1,1,0,0,0,0,0],
            2:[1,1,0,1,1,0,1,0],
            3:[1,1,1,1,0,0,1,0],
            4:[0,1,1,0,0,1,1,0],
            5:[1,0,1,1,0,1,1,0], 
        }
         
   
    def clear_led(self):         
        for led in self.led_lst:
            time.sleep(.01)
            if self.is_anode:
                led.off()
            else:
                led.on()

    def show_num(self,num:int):
        logic_lst =self.num_dict.get(num) 
        print(f"logic_lst:{logic_lst}")

        for i in range(len(logic_lst)):
            logic_item = logic_lst[i]
            if self.is_anode:
                logic_item = not logic_lst[i] 
            self.led_lst[i].value(logic_item)
        

seg = Seg(pin_idxs= [0,2,4,5,12,14,26,33])
seg.clear_led()
seg.show_num(num=5)