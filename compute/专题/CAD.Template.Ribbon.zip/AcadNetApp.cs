﻿using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.Runtime;
using Autodesk.Windows;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


[assembly: ExtensionApplication(typeof($safeprojectname$.AcadNetApp))]
namespace $safeprojectname$
{
    public class AcadNetApp : IExtensionApplication
    {
        public static string assemblyPath = Assembly.GetExecutingAssembly().Location;
        public static string assemblyDir = Path.GetDirectoryName(assemblyPath) + "\\";

        /// <summary>
        /// 启动动作
        /// </summary>
        public void Initialize()
        {
            Application.Idle += OnIdle;
            //需要添加事件，监听工作空间有没有变化，如果有变化，需要重新生成面板
            Application.SystemVariableChanged += new SystemVariableChangedEventHandler(Application_SystemVariableChanged);

        }

        /// <summary>
        /// 关闭动作
        /// </summary>
        public void Terminate()
        {
            // do somehing to cleanup resource 
            Application.Idle -= OnIdle;
            //卸载
            Application.SystemVariableChanged -= new SystemVariableChangedEventHandler(Application_SystemVariableChanged);

        }

        /// <summary>
        /// 启动时行为
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnIdle(object sender, EventArgs e)
        {
            //无论如何 刷新一下工作空间
            var wsCurrent = Application.GetSystemVariable("WSCURRENT");
            Application.SetSystemVariable("WSCURRENT", wsCurrent);

            Application.Idle -= OnIdle;
        }

        /// <summary>
        /// 监听动作
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Application_SystemVariableChanged(object sender, SystemVariableChangedEventArgs e)
        {
            //Editor ed = Application.DocumentManager.MdiActiveDocument.Editor;
            //ed.WriteMessage("\n-Sys Var Changed: " + e.Name);

            if (e.Name.ToLower() == "wscurrent")
            {
                Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage("\n加载程序中...\n");
                AddRibbon();
                Application.DocumentManager.MdiActiveDocument.Editor.WriteMessage("\n加载程序完成\n");
            }
        }

        //==========================================================================================================

        /// <summary>
        /// 需要添加的界面内容
        /// </summary>
        public void AddRibbon()
        {
            RibbonControl ribbonControl = ComponentManager.Ribbon;
            //该步骤自动时可能加载卡住
            RibbonTab ribbonTab = ribbonControl.AddTab("ribbonTab", Guid.NewGuid().ToString(), true);
            RibbonPanelSource panelSource = ribbonTab.AddPanel("ribbonAutoPanel");

            //----- 
            //按下按钮时加载指定dll内功能
            var dllPath = Path.Combine(assemblyDir, "CAD.Demo.dll");
            RibbonButton ribbonButton =
                RibbonService.GenRibbonButton("TestLoadDll", "TestLoadDllText", " ",
                  new LoadDllCommandHandler(dllPath, "CAD.Demo.HelloCommand", "ShowWpfView"),
                               RibbonService.GenImageSource(Resource.ICON_ALL));
            panelSource.Items.Add(ribbonButton);
            //----- 
            //调用CAD内部命令 Line
            RibbonButton lineButton =
            RibbonService.GenRibbonButton("Test_Line", "TestLineText", "Line",
                new RibbonCommandHandler(),
                             RibbonService.GenImageSource(Resource.ICON_ALL));
            panelSource.Items.Add(lineButton);
            //----- 
        }



    }
}
