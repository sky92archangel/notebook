﻿using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.Windows;

using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    /// <summary>
    /// 传统加载方法  通过按钮参数名称调动命令  
    /// 前提是 预先载入带有该命令的 DLL  但是这样会启动时锁定所有写入的功能DLL
    /// 参数必须是 DLL内功能的名称 CommandMethod
    /// </summary>
    public class AcadCommandHandler : System.Windows.Input.ICommand
    {
        public bool CanExecute(object parameter)
        {
            return true;
        }
#pragma warning disable 67
        public event EventHandler CanExecuteChanged;
#pragma warning restore 67
        public void Execute(object parameter)
        {
            //通过参数传达
            if (parameter is RibbonButton)
            {
                RibbonButton btn = (RibbonButton)parameter;
                if (btn.CommandParameter != null)
                {
                    Document doc = Application.DocumentManager.MdiActiveDocument;
                    doc.SendStringToExecute(btn.CommandParameter.ToString() + " ",
                        false, false, false);
                }
                return;
            }
        }
    }


    /// <summary>
    /// 本地DLL加载  即为热加载
    /// 可在按下按钮时加载DLL 并执行DLL内的命令
    /// 更加灵活
    /// 缺点是一个按钮只能绑定DLL的一个方法
    /// </summary>
    public class LoadDllCommandHandler : System.Windows.Input.ICommand
    {
        Action action;

        /// <summary>
        /// 本地DLL加载  即为热加载
        /// </summary>
        /// <param name="dllPath">dll所在目录</param>
        /// <param name="pathToClass">命名空间.类名称</param>
        /// <param name="methodName">方法名称</param>
        /// <param name="constuctParams">后续加入的参数</param>
        public LoadDllCommandHandler(string dllPath, string pathToClass, string methodName, object[] constuctParams = null)
        {
            action = CommandHotLoad.GenCommandAction(dllPath, pathToClass, methodName, constuctParams);
        }

        public bool CanExecute(object parameter)
        {
            return true;
        }
#pragma warning disable 67
        public event EventHandler CanExecuteChanged;
#pragma warning restore 67
        public void Execute(object parameter)
        {
            if (action != null)
            {
                action?.Invoke();
            }
        }
    }



    /// <summary>
    /// 备用功能
    ///  A class to fire commands to AutoCAD
    /// </summary>
    public class RibbonCommandHandler : System.Windows.Input.ICommand
    {
        private string _command = "";
        public RibbonCommandHandler(string cmd)
        {
            _command = cmd;
        }
        public RibbonCommandHandler()
        {
            _command = string.Empty;   //
        }
#pragma warning disable 67
        public event EventHandler CanExecuteChanged;
#pragma warning restore 67
        public bool CanExecute(object parameter)
        {
            return true;
        }
        public void Execute(object parameter)
        {
            //通过参数传达
            if (string.IsNullOrEmpty(_command) && parameter is RibbonButton)
            {
                RibbonButton btn = (RibbonButton)parameter;
                if (btn.CommandParameter != null)
                {
                    Document doc = Application.DocumentManager.MdiActiveDocument;
                    doc.SendStringToExecute(btn.CommandParameter.ToString() + " ",
                        false, false, false);
                }
                return;
            }

            //直接文字命令传达
            if (!string.IsNullOrEmpty(_command))
            {
                Document doc = Application.DocumentManager.MdiActiveDocument;
                doc.SendStringToExecute(_command + " ",
                    false, false, false);
                return;
            }

        }
    }




}
