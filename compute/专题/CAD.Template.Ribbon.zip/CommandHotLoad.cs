﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class CommandHotLoad
    {
        //private Action cmd;

        public static string assemblyPath = Assembly.GetExecutingAssembly().Location;
        public static string assemblyDir = Path.GetDirectoryName(assemblyPath) + "\\";

        /// <summary>
        /// 反射获得所需执行
        /// </summary>
        /// <param name="dllPath"> dll文件路径  C:\\CAD\\bin\\Debug\\SEPD.CadDemo.Space.dll</param>
        /// <param name="pathToClass">命名空间和类的全称 SEPD.CadDemo.Space.Class</param>
        /// <param name="methodName"> 执行方法名  methodName</param>
        /// <returns></returns>
        public static Action GenCommandAction(string dllPath, string pathToClass, string methodName, object[] constuctParams = null)
        {
            var targetAssembly = Assembly.Load(File.ReadAllBytes(dllPath));
            var targetType = targetAssembly.GetType(pathToClass);
            var targetMethod = targetType.GetMethod(methodName);
            var targetObject = Activator.CreateInstance(targetType);

            if (constuctParams == null) { constuctParams = new object[] { }; }
            Action cmd = () => targetMethod.Invoke(targetObject, constuctParams);

            return cmd;

        }


        public static Action GenCommandAction(string dirName, string dllName, string namespaceName, string className, string methodName)
        {
            if (string.IsNullOrEmpty(dirName)) dirName = assemblyPath;

            var adapterFileInfo = new FileInfo(dirName);
            var targetFilePath = Path.Combine(adapterFileInfo.DirectoryName, dllName);
            var targetAssembly = Assembly.Load(File.ReadAllBytes(targetFilePath));
            var targetType = targetAssembly.GetType($"{namespaceName}.{className}");
            //if (targetType == null) { MessageBox.Show("targetType==null", "error++"); return; }
            var targetMethod = targetType.GetMethod(methodName);
            var targetObject = Activator.CreateInstance(targetType);

            object[] constuctParams = new object[] { };
            Action cmd = () => targetMethod.Invoke(targetObject, constuctParams);

            return cmd;

        }


        //=====================================

        //public void Reload()
        //{

        //    var command = GenCommandAction();
        //    try
        //    {
        //        command?.Invoke();
        //    }
        //    catch (Exception ex)
        //    {
        //        //System.Windows.MessageBox.Show(ex.Message, "error++");
        //    }
        //}

        public void Reload_Test()
        {
            var dllPath = Path.Combine(assemblyDir, "CAD.Demo.dll");
            Action command = GenCommandAction(dllPath, "CAD.Demo.HelloCommand", "CadDbText");
            try
            {
                command?.Invoke();
            }
            catch (Exception ex)
            {
                //System.Windows.MessageBox.Show(ex.Message, "error++");
            }
        }

        public void ReloadJson()
        {
            var dllPath = Path.Combine(assemblyDir, "CAD.Demo.dll");
            var command = GenCommandAction(dllPath, "CAD.Demo.HelloCommand", "CadDbText");
            try
            {
                command?.Invoke();
            }
            catch (Exception ex)
            {
                //System.Windows.MessageBox.Show(ex.Message, "error++");
            }
        }






    }
}
