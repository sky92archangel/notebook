﻿using Autodesk.Windows;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
//using Autodesk.Internal.Windows;
//using System.Windows.Forms;

using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace $safeprojectname$
{
    public static partial class RibbonService
    {

        //==========================================================

        public static RibbonTab AddTab(this RibbonControl ribbonControl, string title, string id, bool isActive)
        {
            //TODO
            RibbonTab tab = new RibbonTab();
            tab.Title = title;
            tab.Id = id;
            tab.IsActive = isActive;
            ribbonControl.Tabs.Add(tab);

            return tab;
        }

        public static RibbonPanelSource AddPanel(this RibbonTab ribbonTab, string title)
        {
            RibbonPanelSource panelSource = new RibbonPanelSource();
            panelSource.Title = title;

            RibbonPanel ribbonPanel = new RibbonPanel();
            ribbonPanel.Source = panelSource;

            ribbonTab.Panels.Add(ribbonPanel);

            return panelSource;
        }

        //==========================================================

        /// <summary>
        /// 图像生成
        /// </summary>
        /// <param name="bitmap">   Resource.ICON_ALL</param>
        /// <returns></returns>
        public static ImageSource GenImageSource(Bitmap image)
        {
            //Bitmap image = Resource.ICON_ALL;
            ImageSource imageSource = Imaging.CreateBitmapSourceFromHBitmap(
                image.GetHbitmap(),
                IntPtr.Zero,
                Int32Rect.Empty,
                BitmapSizeOptions.FromEmptyOptions());
            return imageSource;
        }

        /// <summary>
        /// 按钮提示生成
        /// </summary>
        /// <param name="title"></param>
        /// <param name="content"></param>
        /// <param name="command"></param>
        /// <param name="expandedContent"></param>
        /// <param name="imageSource"></param>
        /// <param name="video"></param>
        /// <returns></returns>
        public static RibbonToolTip GenRibbonToolTip(string title, string content, string command,
            string expandedContent,
            ImageSource imageSource = null, Uri video = null)
        {
            RibbonToolTip ribbonToolTip = new RibbonToolTip
            {
                Title = title,
                Content = content,
                Command = command,
                ExpandedContent = expandedContent,
                ExpandedImage = imageSource,
                ExpandedVideo = video
            };
            return ribbonToolTip;
        }


        /// <summary>
        /// 按钮生成
        /// </summary>
        /// <param name="name"></param>
        /// <param name="text"></param>
        /// <param name="commandParam">可以为文字 或 空</param>
        /// <param name="commandHandler"></param>
        /// <param name="imageSource"></param>
        /// <param name="showText"></param>
        /// <param name="showImage"></param>
        /// <param name="toolTip"></param>
        /// <param name="ribbonItemSize"></param>
        /// <param name="orientation"></param>
        /// <param name="mouseEnterEvents">鼠标进入事件</param>
        /// <param name="mouseLeftEvents">鼠标移出事件</param>
        /// <returns></returns>
        public static RibbonButton GenRibbonButton(string name, string text,
            object commandParam,
            ICommand commandHandler,
            ImageSource imageSource = null,
            bool showText = true,
            bool showImage = true,
            ToolTip toolTip = null,
            RibbonItemSize ribbonItemSize = RibbonItemSize.Large,
            Orientation orientation = Orientation.Vertical,
            IEnumerable<EventHandler<EventArgs>> mouseEnterEvents = null,
            IEnumerable<EventHandler<EventArgs>> mouseLeftEvents = null
            )
        {

            RibbonButton ribbonButton = new RibbonButton();
            ribbonButton.Id = Guid.NewGuid().ToString();

            ribbonButton.Name = name;
            //设置文本
            ribbonButton.Text = text;
            //设置命令名称
            if (commandParam != null) ribbonButton.CommandParameter = commandParam;
            //
            if (commandHandler != null) ribbonButton.CommandHandler = commandHandler;

            //显示文本
            ribbonButton.ShowText = showText;
            //显示图案
            ribbonButton.ShowImage = showImage;
            //小图
            ribbonButton.Image = imageSource;
            //大图
            ribbonButton.LargeImage = imageSource;
            //按钮大小
            ribbonButton.Size = RibbonItemSize.Large;
            //要添加这个，这样才能让图片和文字上下，不然就是左右
            ribbonButton.Orientation = Orientation.Vertical;

            //设置提示
            if (toolTip != null) ribbonButton.ToolTip = toolTip;

            //鼠标进入和出去事件
            if (mouseEnterEvents != null && mouseEnterEvents.Count() > 0)
            {
                foreach (var mouseEnterEvent in mouseEnterEvents)
                {
                    ribbonButton.MouseEntered += mouseEnterEvent;
                }
            }
            if (mouseLeftEvents != null && mouseLeftEvents.Count() > 0)
            {
                foreach (var mouseLeftEvent in mouseLeftEvents)
                {
                    ribbonButton.MouseLeft += mouseLeftEvent;
                }
            }

            return ribbonButton;
        }


    }
}
