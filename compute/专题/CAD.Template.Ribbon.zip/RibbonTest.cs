﻿using Autodesk.AutoCAD.Runtime;
using Autodesk.Windows;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class RibbonTest
    {
        public static string assemblyPath = Assembly.GetExecutingAssembly().Location;
        public static string assemblyDir = Path.GetDirectoryName(assemblyPath) + "\\";

        [CommandMethod("RibbonTestCommand")]
        public void RibbonTestCommand()
        {
            RibbonControl ribbonControl = ComponentManager.Ribbon;
            RibbonTab ribbonTab = ribbonControl.AddTab("RibbonTest", Guid.NewGuid().ToString(), true);

            RibbonPanelSource panelSource = ribbonTab.AddPanel("PanelTest");

            RibbonButton ribbonButton =
            RibbonService.GenRibbonButton("Test_Line", "TestLineText", "Line",
                new RibbonCommandHandler(),
                RibbonService.GenImageSource(Resource.ICON_ALL));
            panelSource.Items.Add(ribbonButton);
        }

    }
}
